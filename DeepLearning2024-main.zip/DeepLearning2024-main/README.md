# Captcha Model for the DeapLearning 2024 course at the JADS.
This a captcha solving model created in PyTorch using CTCLoss and CNN and RNN Resnet architecture.
The code in this repository has been inspired by https://github.com/abhishekkrthakur/captcha-recognition-pytorch.